export const whatsappNumber = "5493400536380";
export const displayPhone = "+54 9 3400 53-6380";

export const whatsappMessages = {
  general:
    "Hola Ezequiel, vi tu página web y quería consultarte por un trabajo de construcción.",
  quote:
    "Hola Ezequiel, quisiera solicitar un presupuesto para un trabajo de albañilería.",
  project:
    "Hola Ezequiel, tengo un proyecto en mente y quería contarte qué necesito hacer.",
};

export function whatsappUrl(message: string) {
  return `https://wa.me/${whatsappNumber}?text=${encodeURIComponent(message)}`;
}

// Incorporar aquí únicamente fotografías reales autorizadas por Ezequiel.
// Las rutas deben apuntar a archivos dentro de public/images/.
export const siteMedia = {
  hero: "",
  about: "",
};

export type ProjectCategory =
  | "Construcción y estructuras"
  | "Revoques y terminaciones"
  | "Pisos y revestimientos"
  | "Piletas y exteriores"
  | "Instalaciones y aberturas"
  | "Refacciones";

export type Project = {
  id: string;
  title: string;
  category: ProjectCategory;
  image: string;
  alt: string;
  layout: "vertical" | "horizontal" | "cuadrado";
  beforeImage?: string;
  beforeAlt?: string;
};

// Cada nueva entrada aparece automáticamente en la galería, sus filtros y el visor.
export const projects: Project[] = [];

export const services = [
  {
    id: "construccion",
    title: "Construcción y estructuras",
    items: [
      "Bases para columnas",
      "Encadenados",
      "Construcción de paredes de ladrillo del 12",
      "Columnas para tinglados",
      "Armado de columnas y trabajos de encofrado",
    ],
  },
  {
    id: "revoques",
    title: "Revoques y terminaciones",
    items: [
      "Revoque grueso",
      "Revoque fino",
      "Revoque exterior",
      "Terminaciones finas",
      "Revoques con colocación de ladrillos de vidrio",
    ],
  },
  {
    id: "pisos",
    title: "Pisos y revestimientos",
    items: [
      "Armado de carpetas",
      "Colocación de pisos cerámicos",
      "Colocación de revestimientos",
      "Instalación de pisos y cerámicos en baños",
    ],
  },
  {
    id: "piletas",
    title: "Piletas y exteriores",
    items: [
      "Fabricación y colocación de losetas de diseño para piletas",
      "Losetas decorativas para bordes y laterales de piscinas",
      "Trabajos de terminación en exteriores",
    ],
  },
  {
    id: "instalaciones",
    title: "Instalaciones y aberturas",
    items: [
      "Colocación de puertas y ventanas",
      "Instalación de aberturas",
      "Terminaciones y revoques posteriores a la colocación",
    ],
  },
  {
    id: "refacciones",
    title: "Refacciones y otros trabajos",
    items: [
      "Pintura",
      "Instalación de placas de Durlock",
      "Remodelaciones",
      "Trabajos generales de albañilería",
    ],
  },
] as const;