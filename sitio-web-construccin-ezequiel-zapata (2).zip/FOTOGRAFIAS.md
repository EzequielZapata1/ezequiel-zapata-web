# Fotografías reales del sitio

El sitio no incluye fotografías de muestra, de stock ni generadas. Para publicar las imágenes de Ezequiel:

1. Guardar los archivos optimizados en `public/images/` (preferentemente WebP o AVIF, con nombres descriptivos).
2. Indicar la portada y la foto de presentación en `siteMedia`, dentro de `src/data/site.ts`, por ejemplo `hero: "/images/portada.webp"`.
3. Agregar cada trabajo al arreglo `projects` en ese mismo archivo. Ejemplo de estructura (reemplazar los datos por los reales):

```ts
{
  id: "obra-01",
  title: "Nombre del trabajo",
  category: "Pisos y revestimientos",
  image: "/images/trabajo-01.webp",
  alt: "Descripción precisa de la fotografía real",
  layout: "horizontal", // "vertical", "horizontal" o "cuadrado"
  // Opcional para una comparación antes/después:
  beforeImage: "/images/trabajo-01-antes.webp",
  beforeAlt: "Descripción del estado anterior",
}
```

Las fotografías se mostrarán en la galería con filtros, visor de pantalla completa y navegación por teclado. Si se incluye `beforeImage`, el visor permitirá alternar entre antes y después. Las fotos de portada y presentación solo aparecen cuando se configuran rutas válidas.

Al publicar el sitio con un dominio definitivo, cambiar `og:image` en `index.html` por la URL absoluta de `og-cover.png` para mejorar la vista previa al compartir en redes.